<footer class="bg-blue-950 text-white pt-20 pb-10 border-t border-blue-900">
    <div class="max-w-7xl mx-auto px-6">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
            
            <!-- Brand Info -->
            <div class="space-y-6">
                <h3 class="text-2xl font-bold text-yellow-400 uppercase tracking-wider">
                    <?php bloginfo('name'); ?> <br/> <span class="text-white"><?php bloginfo('description'); ?></span>
                </h3>
                <p class="text-blue-200 leading-relaxed">
                    <?php echo get_theme_mod('footer_text', 'Modern ekipmanlar ve uzman kadromuzla Eskişehir\'in her noktasına hızlı ve güvenilir tesisat çözümleri sunuyoruz.'); ?>
                </p>
                <div class="flex gap-4">
                    <a href="#" class="bg-blue-900 p-2 rounded-lg hover:bg-yellow-400 hover:text-blue-950 transition-colors">
                        <i class="fab fa-facebook text-lg"></i>
                    </a>
                    <a href="#" class="bg-blue-900 p-2 rounded-lg hover:bg-yellow-400 hover:text-blue-950 transition-colors">
                        <i class="fab fa-instagram text-lg"></i>
                    </a>
                    <a href="#" class="bg-blue-900 p-2 rounded-lg hover:bg-yellow-400 hover:text-blue-950 transition-colors">
                        <i class="fab fa-twitter text-lg"></i>
                    </a>
                </div>
            </div>

            <!-- Hizmet Bölgeleri -->
            <div>
                <h4 class="text-xl font-bold mb-6 border-b-2 border-yellow-400 inline-block pb-2">Hizmet Bölgelerimiz</h4>
                <ul class="space-y-3 text-blue-200">
                    <!-- Bu liste dinamik de olabilir ama şimdilik statik örnek bırakıyoruz veya bir menü tanımlayabiliriz -->
                    <?php 
                    // Basitlik için statik liste, ileride WP Menüsü bağlanabilir
                    $locations = ['Çamlıca', 'Büyükdere', '71 Evler', 'Emek', 'Eskibağlar', 'Batıkent'];
                    foreach($locations as $loc):
                    ?>
                    <li>
                        <a href="#" class="hover:text-yellow-400 transition-colors flex items-center gap-2 text-sm">
                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#eab308" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
                            <?php echo $loc; ?> Su Tesisatçısı
                        </a>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <!-- Services (WP Query) -->
            <div>
                <h4 class="text-xl font-bold mb-6 border-b-2 border-yellow-400 inline-block pb-2">Hizmetlerimiz</h4>
                <ul class="space-y-3 text-blue-200">
                    <?php
                    $services_query = new WP_Query(array(
                        'post_type' => 'service',
                        'posts_per_page' => 5
                    ));
                    if ($services_query->have_posts()) :
                        while ($services_query->have_posts()) : $services_query->the_post(); ?>
                        <li>
                            <a href="<?php the_permalink(); ?>" class="hover:text-yellow-400 cursor-pointer flex items-center gap-2 text-sm">
                                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#eab308" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
                                <?php the_title(); ?>
                            </a>
                        </li>
                        <?php endwhile;
                        wp_reset_postdata();
                    else : ?>
                        <li><span class="text-sm">Henüz hizmet eklenmedi.</span></li>
                    <?php endif; ?>
                </ul>
            </div>

            <!-- Contact -->
            <div>
                <h4 class="text-xl font-bold mb-6 border-b-2 border-yellow-400 inline-block pb-2">İletişim</h4>
                <ul class="space-y-6">
                    <li class="flex items-start gap-4">
                        <div class="bg-yellow-400 p-2 rounded-full text-blue-950 shrink-0">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
                        </div>
                        <span class="text-blue-200"><?php echo get_theme_mod('footer_address', 'İstiklal Mah. Şair Fuzuli Cad. No:123 Odunpazarı / Eskişehir'); ?></span>
                    </li>
                    <li class="flex items-center gap-4">
                        <div class="bg-yellow-400 p-2 rounded-full text-blue-950 shrink-0">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                        </div>
                        <span class="text-blue-200 text-lg font-bold"><?php echo get_theme_mod('footer_phone', '+90 555 123 45 67'); ?></span>
                    </li>
                    <li class="flex items-center gap-4">
                        <div class="bg-yellow-400 p-2 rounded-full text-blue-950 shrink-0">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
                        </div>
                        <span class="text-blue-200"><?php echo get_theme_mod('footer_email', 'iletisim@tikaniklikacma.com'); ?></span>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Copyright -->
        <div class="border-t border-blue-900 pt-8 text-center text-blue-400 text-sm">
            <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. Tüm hakları saklıdır.</p>
        </div>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
