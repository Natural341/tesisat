<?php

function tesisat_pro_setup() {
    // Başlık etiketi desteği
    add_theme_support('title-tag');

    // Öne çıkan görsel desteği
    add_theme_support('post-thumbnails');

    // Logo desteği
    add_theme_support('custom-logo', array(
        'height'      => 100,
        'width'       => 400,
        'flex-height' => true,
        'flex-width'  => true,
    ));

    // Menü kaydı
    register_nav_menus(array(
        'primary' => __('Ana Menü', 'tesisat-pro'),
        'footer'  => __('Footer Menü', 'tesisat-pro'),
    ));
}
add_action('after_setup_theme', 'tesisat_pro_setup');

// Script ve Stil Dosyaları
function tesisat_pro_scripts() {
    // Tailwind CSS (CDN - Geliştirme için)
    wp_enqueue_script('tailwindcss', 'https://cdn.tailwindcss.com', array(), '3.4.0', false);
    
    // FontAwesome veya Lucide ikonları için bir çözüm (Burada Lucide React bileşeni kullanamayız, SVG veya FontAwesome kullanmalıyız. 
    // Tasarımı bozmamak için Lucide ikonlarının SVG çıktılarını kullanacağım ama genel kullanım için FontAwesome ekliyorum)
    wp_enqueue_style('fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css');

    // Ana stil dosyası
    wp_enqueue_style('tesisat-pro-style', get_stylesheet_uri());
    
    // Tailwind Config (Renkler vb. için)
    wp_add_inline_script('tailwindcss', "
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        blue: {
                            900: '#1e3a8a',
                            950: '#172554',
                        },
                        yellow: {
                            400: '#facc15',
                            500: '#eab308',
                        }
                    }
                }
            }
        }
    ");
}
add_action('wp_enqueue_scripts', 'tesisat_pro_scripts');

// Hizmetler (Custom Post Type) Oluşturma
function create_service_cpt() {
    register_post_type('service',
        array(
            'labels' => array(
                'name' => __('Hizmetler'),
                'singular_name' => __('Hizmet')
            ),
            'public' => true,
            'has_archive' => true,
            'menu_icon' => 'dashicons-hammer',
            'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'),
            'show_in_rest' => true,
        )
    );
}
add_action('init', 'create_service_cpt');

// Hizmetler için Kategori (Taxonomy)
function create_service_taxonomy() {
    register_taxonomy(
        'service_category',
        'service',
        array(
            'label' => __('Hizmet Kategorileri'),
            'rewrite' => array('slug' => 'hizmet-kategori'),
            'hierarchical' => true,
            'show_in_rest' => true,
        )
    );
}
add_action('init', 'create_service_taxonomy');
